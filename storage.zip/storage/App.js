import React, { useState } from 'react';
import { Button, Text, View, TextInput } from 'react-native';
import storage from './storage';
export default function App() {
  const [username, setUsername] = useState('');
  const [usernameLocal, setUsernameLocal] = useState('');
  return (
    <View style={{ margin: 50 }}>
      <Text> offline Storage </Text>
      <TextInput
        value={username}
        onChangeText={setUsername}
        placeholder="Enter user name "
      />
      <Button
        title="Save"
        onPress={() => {
          storage.save({
            key: 'loginState',
            data: { name: username },
            expires: 1000 * 3600,
          });
        }}
      />

      <Button
        style={{ margin: 50 }}
        title="Load"
        onPress={() => {
          storage
            .load({ key: 'loginState' })
            .then((ret) => {
              // found data go to then()
              setUsernameLocal(ret.name);
            })
            .catch((err) => {
              // any exception including data not found goes to catch()
              setUsernameLocal('Empty');
              console.warn(err.message);
              switch (err.name) {
                case 'NotFoundError':
                  // TODO;
                  break;
                case 'ExpiredError':
                  // TODO
                  break;
              }
            });
        }}
      />

      <Button
        style={{ margin: 50 }}
        title="Remove"
        onPress={() => {
          // remove a single record
          storage.remove({
            key: 'loginState',
          });
        }}
      />
      <Text> Local Storage : {usernameLocal} </Text>
    </View>
  );
}
